const help = (prefix) => {
	return `
❣ *ShinoaHiiragi* ❣

Halo, @${groupMem[i].id.replace(/@c.us/g, '')}\n

SELAMAT DATANG DI GROUP *${name}*

gunakan *${prefix}menu* atau *${prefix}help*

> *Sticker Commands* <
==> command : *${prefix}sticker* or *${prefix}stiker*
	desc : mengubah gambar/gif/vdeo menjadi sticker
	usage : reply image/gif/video, or send image/gif/video with caption\n
==> command : *${prefix}sticker nobg* or *${prefix}stiker nobg*
	desc : mengubah gambar menjadi sticker dengan background transparan
	usage : reply image, or send image with caption\n
==> command : *${prefix}toimg*
	desc : mengubah sticker menjadi gambar
	usage : reply sticker\n
==> command : *${prefix}tsticker* or *${prefix}tstiker*
	desc : mengubah teks menjadi sticker
	usage : *${prefix}tsticker teks disini*\n
> *Meme Commands* <
==> command : *${prefix}meme*
	desc : random meme [english]
	usage : tinggal kirim pesan\n
==> command : *${prefix}memeindo*
	desc : random meme indo [indo]
	usage : tinggal kirim pesan\n
> *Others Commands* <
==> command : *${prefix}gtts*
	desc : mengubah text menjadi suara
	usage : *${prefix}gtts [cc] [text]*\nexample : *${prefix}gtts ja On2-chan*\n
==> command : *${prefix}loli*
	desc : random loli images
	usage : just send the command\n
==> command : *${prefix}nsfwloli*
	desc : random nsfw loli images
	usage : just send the command\n
==> command : *${prefix}url2img*
	desc : screenshot web
	usage : *${prefix}url2img [tipe] [url]*\n
==> command : *${prefix}simi*
	desc : pesan kamu akan ter-reply ke simi
	usage : *${prefix}simi yourmessage*\n
==> command : *${prefix}ocr*
	desc : mengambil text dari gambar
	usage : reply gambar, atau kirim gambar dengan caption\n
==> command : *${prefix}wait*
	desc : mencari judul anime [ What Anime Is This/That ]
	usage : reply gambar, atau kirim gambar dengan caption\n
==>command : *${prefix}setprefix*
	desc : mengganti prefix
	usage : *${prefix}setprefix [text|optional]*\nexample : *${prefix}setprefix ?*
	note : command ini hanya dapat digunakan oleh owner\n
> *Group Comands* <
==> command : *${prefix}add*
	desc : masukin orang ke grup
	usage : *${prefix}add 6283807175250*\n
	note : bisa digunakan ketika bot admin, dan orang yang memerintahkan juga admin!\n
==> command : *${prefix}kick*
	desc : kick member dari grup
	usage : *${prefix}kick @tagmember*\n
	note : bisa digunakan ketika bot admin, dan orang yang memerintahkan juga admin!\n
==>command : *${prefix}promote*
	desc : member menjadi admin
	usage : *${prefix}promote @tagmember*\n
	note : bisa digunakan ketika bot admin, dan orang yang memerintahkan juga admin!\n
==> command : *${prefix}demote*
	desc : admin menjadi member biasa
	usage : *${prefix}demote @tagmember*\n
	note : bisa digunakan ketika bot admin, dan orang yang memerintahkan juga admin!\n
==> command : *${prefix}linkgroup*
	desc : dapatkan link grup
	usage : tinggal kirim pesan
	note : bisa digunakan ketika bot admin, dan orang yang memerintahkan juga admin!\n
==> command : *${prefix}leave*
	desc : bot keluar dari grup
	usage : tinggal kirim pesan
	note : Hanya admin dan owner bot\n
==> command : *${prefix}tagall*
	desc : tag semua member
	usage : tinggal kirim pesan
	note : command ini dapat digunakan ketika anda adalah admin\n
==> command : *${prefix}simih*
	desc : mengaktifkan simi mode
	usage : *${prefix}simih 1* untuk mengaktifkan *${prefix}simih 0* untuk non aktifkan
	note : command ini dapat digunakan ketika anda adalah admin\n
	
My Channel : https://youtube.com/channel/UCQvUScoFEjZ2m1AwO8Z1cPg

Bot tidak berjalan 24 jam

Bot by Hardiansyah`
}

exports.help = help
